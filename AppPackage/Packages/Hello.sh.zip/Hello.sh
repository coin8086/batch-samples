#!/bin/bash

name=${1:-'Batch'}

echo "Hello, $name!"
