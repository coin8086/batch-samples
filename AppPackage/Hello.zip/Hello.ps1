param(
    [string] $name = "Batch"
)

"Hello, $name!"
